return  {
	name = "8Bitdo SF30 Pro",
	buttons = {
		a = "5",
		b = "2",
		c = "1",
		x = "9",
		y = "10",
		z = "4",
		l = "7",
		r = "8",
		start = "12",
		select = "11",
		hotkey = "11",
	},
}
