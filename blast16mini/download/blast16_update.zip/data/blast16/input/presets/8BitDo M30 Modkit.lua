return  {
	name = "8BitDo M30 Modkit",
	buttons = {
		a = "2",
		b = "1",
		c = "8",
		x = "5",
		y = "4",
		z = "7",
		l = "",
		r = "",
		start = "12",
		select = "11",
		hotkey = "11",
	},
}
