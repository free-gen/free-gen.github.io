return  {
	name = "USB Gamepad ",
	buttons = {
		a = "2",
		b = "3",
		c = "5",
		x = "1",
		y = "4",
		z = "6",
		l = "7",
		r = "8",
		start = "10",
		select = "9",
	},
}
