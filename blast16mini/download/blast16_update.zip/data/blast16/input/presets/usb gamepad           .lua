return  {
	name = "usb gamepad           ",
	buttons = {
		a = "1",
		b = "2",
		c = "3",
		x = "4",
		y = "5",
		z = "6",
		l = "",
		r = "",
		start = "10",
		select = "9",
		hotkey = "9",
	},
}
