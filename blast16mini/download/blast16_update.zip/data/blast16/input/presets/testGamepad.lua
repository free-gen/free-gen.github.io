return  {
	name = "testGamepad",
	buttons = {
		a = "",
		b = "",
		c = "",
		x = "",
		y = "",
		z = "",
		l = "",
		r = "",
		start = "",
		select = "",
		hotkey = "",
	},
}
