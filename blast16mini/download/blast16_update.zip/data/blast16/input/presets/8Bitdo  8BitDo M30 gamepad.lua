return  {
	name = "8Bitdo  8BitDo M30 gamepad",
	buttons = {
		a = "1",
		b = "2",
		c = "8",
		x = "4",
		y = "5",
		z = "7",
		l = "9",
		r = "10",
		start = "12",
		select = "11",
		hotkey = "11",
	},
}
