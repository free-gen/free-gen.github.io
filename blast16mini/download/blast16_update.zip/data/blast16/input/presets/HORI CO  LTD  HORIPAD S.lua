return  {
	name = "HORI CO LTD  HORIPAD S",
	buttons = {
		a = "1",
		b = "2",
		c = "3",
		x = "4",
		y = "5",
		z = "6",
		l = "7",
		r = "8",
		start = "10",
		select = "9",
		hotkey = "13",
	},
}
