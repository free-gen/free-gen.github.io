return  {
	name = "Xbox 360 Wireless Receiver",
	buttons = {
		a = "3",
		b = "1",
		c = "2",
		x = "5",
		y = "4",
		z = "6",
		l = "",
		r = "",
		start = "8",
		select = "7",
		hotkey = "7",
	},
}
