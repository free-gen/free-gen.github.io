return  {
	name = "8Bitdo SFC30 GamePad",
	buttons = {
		a = "5",
		b = "2",
		c = "1",
		x = "7",
		y = "4",
		z = "8",
		l = "",
		r = "",
		start = "12",
		select = "11",
		hotkey = "11",
	},
}
