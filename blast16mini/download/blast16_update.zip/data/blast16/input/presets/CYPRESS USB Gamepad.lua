return  {
	name = "CYPRESS USB Gamepad",
	buttons = {
		a = "1",
		b = "2",
		c = "3",
		x = "4",
		y = "5",
		z = "6",
		l = "7",
		r = "8",
		start = "9",
		select = "",
		hotkey = "7",
	},
}
