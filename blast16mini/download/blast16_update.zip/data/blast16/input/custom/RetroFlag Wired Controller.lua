return  {
	name = "RetroFlag Wired Controller",
	buttons = {
		a = "1",
		b = "2",
		c = "10",
		x = "3",
		y = "4",
		z = "9",
		l = "5",
		r = "6",
		start = "8",
		select = "7",
		hotkey = "7",
	},
}
