#!/bin/bash

sudo killall run.sh >/dev/null 2>&1
sudo killall python >/dev/null 2>&1

if pgrep -x "blast16" > /dev/null
then
        sudo killall blast16 >/dev/null 2>&1
else
        touch /tmp/stop
        sudo killall retroarch >/dev/null 2>&1
fi

setterm -cursor on

clear
