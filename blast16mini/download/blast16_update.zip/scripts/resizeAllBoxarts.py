from os import listdir, stat, system
from os.path import isfile, join, exists
import time
import commands

preffix = "[Resize all boxarts]"

mainPath = "/home/pi/blast16/"
systems = [ "32x", "md", "ms", "gg", "cd" ]

for sys in systems:
	boxartspath = mainPath + "games/" + sys + "/boxarts/"
	datapath = mainPath + "data/blast16/"

	existPngs = 0
	filelist = listdir(boxartspath)
	for f in filelist[:]:
		if (f.endswith(".png")):
			existPngs = 1

	if (existPngs == 1):
		print (preffix + " Converting png to jpg" )
		system('mogrify -format jpg ' + boxartspath + '*.png')

		print (preffix + " Removing png files, if any")
		system('rm ' + boxartspath + '*.png')


	boxartfiles = [f for f in listdir(boxartspath) if isfile( join( boxartspath, f ) )]
	
	for f in boxartfiles:
		if ( f.find( ".jpg" ) != -1 ):
			boxartpath = join( boxartspath, f )
			
			size = commands.getoutput('identify -ping -format "%wx%h" "' +  boxartpath + '"')
			sizeArray = size.split("x")
			width = sizeArray[0]
			height = sizeArray[1]
			# print (boxartpath + " SIZE: " + size)

			if (float(width)/float(height) > 0.9):
				print (preffix + " Resize boxart to 230x230: " + f)
				system('convert "' + boxartpath + '" -resize "230x230!" "' +  boxartpath + '"' )
			elif(float(width)/float(height) < 0.9 and float(width)/float(height) > 0.75):
				print (preffix + " Resize boxart to 230x264: " + f)
				system('convert "' + boxartpath + '" -resize "230x264!" "' +  boxartpath + '"' )
			elif(float(width)/float(height) < 0.75 and float(width)/float(height) > 0.62):
				print (preffix + " Resize boxart to 230x320: " + f)
				system('convert "' + boxartpath + '" -resize "230x320!" "' +  boxartpath + '"' )
			else:
				print (preffix + " Resize boxart to 190x320: " + f)
				system('convert "' + boxartpath + '" -resize "190x320!" "' +  boxartpath + '"' )
