from os import listdir, stat, system 
from os.path import isfile, join, exists 
import time 
import commands 

valuefile = "/tmp/bilinearFilter"
configfile = "/home/pi/.config/retroarch/retroarch.cfg"

filter = ""
if ( exists( valuefile )) :
	f = open (valuefile, "r")
	lines = f.readlines()
	f.close()
	filter = lines[0]
	
	if ( exists( configfile ) ) :
		spf = open(configfile, "r")
		splines = spf.readlines()
		spf.close()

		content = ""
		for line in splines:
			if (line.find("video_smooth =") <> -1):
				content = content  + "video_smooth = \"" + filter + "\"\n"
			else:
				content = content + line

		spf = open (configfile, "w")
		spf.write(content)
		spf.close()
