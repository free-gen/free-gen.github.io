from os import listdir, stat, system
from os.path import isfile, join, exists
import commands

ipfile = "/home/pi/blast16/data/blast16/ip.txt"

ifconfig = commands.getoutput('ifconfig eth0 | grep "inet "')

content = ""
if (ifconfig.find("netmask") <> -1):
	ip = ifconfig[ifconfig.find("inet ") + 5:ifconfig.find("netmask") - 2]
	# print ("---" + ip + "---")
	content = ip
	
if (content == ""):
	ifconfig = commands.getoutput('ifconfig wlan0 | grep "inet "')
	content = ""
	if (ifconfig.find("netmask") <> -1):
		ip = ifconfig[ifconfig.find("inet ") + 5:ifconfig.find("netmask") - 2]
		# print ("---" + ip + "---")
		content = ip

ipf = open (ipfile, "w")
ipf.write(content)
ipf.close()