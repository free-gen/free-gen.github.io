from os import listdir, stat, system 
from os.path import isfile, join, exists 
import time 
import commands 

valuefile = "/tmp/scanlines"
gpconfigfile = "/home/pi/.config/retroarch/shaders/presets/Genesis Plus GX/Genesis Plus GX.glslp"
pdconfigfile = "/home/pi/.config/retroarch/shaders/presets/PicoDrive/PicoDrive.glslp"

shaders = ""
if ( exists( valuefile )) :
	f = open (valuefile, "r")
	lines = f.readlines()
	f.close()
	shaders = lines[0][0:1]

	if ( exists( gpconfigfile ) ) :
		spf = open(gpconfigfile, "r")
		splines = spf.readlines()
		spf.close()

		content = ""
		for line in splines:
			if (line.find("shaders =") <> -1):
				content = content  + "shaders = \"" + shaders + "\"\n"
			else:
				content = content + line

		spf = open (gpconfigfile, "w")
		spf.write(content)
		spf.close()

	if ( exists( pdconfigfile ) ) :
		spf = open(pdconfigfile, "r")
		splines = spf.readlines()
		spf.close()

		content = ""
		for line in splines:
			if (line.find("shaders =") <> -1):
				content = content  + "shaders = \"" + shaders + "\"\n"
			else:
				content = content + line

		spf = open (pdconfigfile, "w")
		spf.write(content)
		spf.close()
