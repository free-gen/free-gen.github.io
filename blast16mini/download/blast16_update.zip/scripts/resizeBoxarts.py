from os import listdir, stat, system
from os.path import isfile, join, exists
import time
import commands

preffix = "[Resize boxarts]"

mainPath = "/home/pi/blast16/"
systems = [ "md", "ms", "gg", "cd", "32x" ]

for sys in systems:
	boxartspath = mainPath + "games/" + sys + "/boxarts/"
	datapath = mainPath + "data/blast16/"

	existPngs = 0
	filelist = listdir(boxartspath)
	for f in filelist[:]:
		if (f.endswith(".png")):
			# print ("FILE: " + f)
			existPngs = 1
			break

	if (existPngs == 1):
		print (preffix + " Converting png to jpg" )
		# system('ls -al *.png')
		system('mogrify -format jpg ' + boxartspath + '*.png')

		print (preffix + " Removing png files, if any")
		system('rm -v ' + boxartspath + '*.png')


	boxartfiles = [f for f in listdir(boxartspath) if isfile( join( boxartspath, f ) )]
	rtfilename = "lastResizeBoxartTime.txt"

	if ( exists( join( datapath, rtfilename ) ) ):
		rtfile = open ( join( datapath, rtfilename ), "r" )
		lastresizetime = rtfile.read()
		lastresizetime = float(lastresizetime)
		rtfile.close()
	else:
		#print "No last resize time file found"
		lastresizetime = 0
		#lastresizetime = time.time()
		rtfile = open ( join( datapath, rtfilename ), "w+" )
		rtfile.write( str(lastresizetime ) )
		rtfile.close()


	modifyRtfile = False

	for f in boxartfiles:
		if ( f.find( ".jpg" ) != -1 ):
			boxartpath = join( boxartspath, f )
			status = stat( boxartpath )
			# if (sys != "md"):
				# print ("BOXART: " + boxartpath)
				# print ("LAST RESIZE TIME: " + str(lastresizetime))
				# print ("BOXART TIME: " + str(status.st_mtime))


			if ( status.st_mtime > lastresizetime ):
				modifyRtfile = True
				# print ("--------------------ENTRA AQUI-----------------")
				size = commands.getoutput('identify -ping -format "%wx%h" "' +  boxartpath + '"')
				sizeArray = size.split("x")
				width = sizeArray[0]
				height = sizeArray[1]

				if ( float( width ) > 230 or float(height) > 320 ):
					if (float(width)/float(height) > 0.9):
						print (preffix + " Resize boxart to 230x230: " + f)
						system('convert "' + boxartpath + '" -resize "230x230!" "' +  boxartpath + '"' )
					elif(float(width)/float(height) < 0.9 and float(width)/float(height) > 0.75):
						print (preffix + " Resize boxart to 230x264: " + f)
						system('convert "' + boxartpath + '" -resize "230x264!" "' +  boxartpath + '"' )
					elif(float(width)/float(height) < 0.75 and float(width)/float(height) > 0.62):
						print (preffix + " Resize boxart to 230x320: " + f)
						system('convert "' + boxartpath + '" -resize "230x320!" "' +  boxartpath + '"' )
					else:
						print (preffix + " Resize boxart to 190x320: " + f)
						system('convert "' + boxartpath + '" -resize "190x320!" "' +  boxartpath + '"' )


if (modifyRtfile):
	rtfile = open( join( datapath, rtfilename ), "w+" )
	rtfile.write( str( time.time( ) ) )
	rtfile.close()

