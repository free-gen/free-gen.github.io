#!/bin/bash

# RESTORE
if [ -e '/dev/sda1' ]; then
	USBDEV='/dev/sda1'
elif [ -e '/dev/sdb1' ]; then
	USBDEV='/dev/sdb1'
fi


if [ -n "$USBDEV" ]; then
	if [ ! -d '/mnt/usb' ]; then
		sudo mkdir '/mnt/usb'
	fi


	# Detect USB format and mount accordingly
	USBFORMAT=`sudo blkid | grep $USBDEV | tr -s ' ' | cut -d ' ' -f 4 | cut -d '=' -f 2 | sed 's/"//g'`
	if [ "$USBFORMAT" == "exfat" ]; then
		sudo mount -t exfat "$USBDEV" /mnt/usb
		echo "exfat USB Mounted"
	else 
		sudo mount "$USBDEV" /mnt/usb
		echo "USB Mounted"
	fi


	if [ -d '/mnt/usb/blast16_backup' ]; then
		echo "Restore started. Please wait."
		
		sudo cp -Rvf /mnt/usb/blast16_backup/blast16/* /home/pi/blast16
		sudo cp -Rvf /mnt/usb/blast16_backup/retroarch/* /home/pi/.config/retroarch/

		if [ -f '/mnt/usb/blast16_backup/wpa_supplicant.conf' ]; then
			sudo cp -vf /mnt/usb/blast16_backup/wpa_supplicant.conf /etc/wpa_supplicant/
		fi 

		sudo umount /mnt/usb

		echo "---------------------------------"
		echo  "Finished restoring system. You can safely remove the USB drive. System will reboot in a few seconds."
		
		sleep 3

		sudo reboot
	else
		echo "[ERROR] blast16_backup directory not found. Restore cancelled. System will reboot in a few seconds."
		
		sleep 3

		sudo reboot
	fi
fi
