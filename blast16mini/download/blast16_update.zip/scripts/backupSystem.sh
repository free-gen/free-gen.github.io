#!/bin/bash


# BACKUP
if [ -e '/dev/sda1' ]; then
	USBDEV='/dev/sda1'
elif [ -e '/dev/sdb1' ]; then
	USBDEV='/dev/sdb1'
fi


if [ -n "$USBDEV" ]; then
	if [ ! -d '/mnt/usb' ]; then
		sudo mkdir '/mnt/usb'
	fi

	# Detect USB format and mount accordingly
	USBFORMAT=`sudo blkid | grep $USBDEV | tr -s ' ' | cut -d ' ' -f 4 | cut -d '=' -f 2 | sed 's/"//g'`
	if [ "$USBFORMAT" == "exfat" ]; then
		sudo mount -t exfat "$USBDEV" /mnt/usb
		echo "exfat USB Mounted"
	else 
		sudo mount "$USBDEV" /mnt/usb
		echo "USB Mounted"
	fi


	if [ ! -d '/mnt/usb/blast16_backup' ]; then
		sudo mkdir '/mnt/usb/blast16_backup'
	fi
	if [ ! -d '/mnt/usb/blast16_backup/blast16' ]; then
		sudo mkdir '/mnt/usb/blast16_backup/blast16'
	fi

	echo "Backup started. Please wait."
	
	sudo cp -Rvf /home/pi/blast16/games /mnt/usb/blast16_backup/blast16/
	sudo cp -Rvf /home/pi/blast16/saves /mnt/usb/blast16_backup/blast16/
	sudo cp -Rvf /home/pi/blast16/bios /mnt/usb/blast16_backup/blast16/

	sudo cp -Rvf /home/pi/blast16/data /mnt/usb/blast16_backup/blast16/
	sudo rm -Rv /mnt/usb/blast16_backup/blast16/data/blast16/input/presets
	sudo rm -Rv /mnt/usb/blast16_backup/blast16/data/blast16/img
	
	# sudo cp -Rvf /home/pi/.config/retroarch /mnt/usb/blast16_backup/
	
	# Retroarch stuff
	if [ ! -d '/mnt/usb/blast16_backup/retroarch' ]; then
		sudo mkdir '/mnt/usb/blast16_backup/retroarch'
	fi
	
	sudo cp -Rvf /home/pi/.config/retroarch/retroarch.cfg /mnt/usb/blast16_backup/retroarch/
	
	if [ ! -d '/mnt/usb/blast16_backup/retroarch/autoconfig' ]; then
		sudo mkdir '/mnt/usb/blast16_backup/retroarch/autoconfig'
	fi
	sudo cp -Rvf /home/pi/.config/retroarch/autoconfig/udev /mnt/usb/blast16_backup/retroarch/autoconfig

	sudo cp -Rvf /home/pi/.config/retroarch/config /mnt/usb/blast16_backup/retroarch

	if [ ! -d '/mnt/usb/blast16_backup/retroarch/cores' ]; then
		sudo mkdir '/mnt/usb/blast16_backup/retroarch/cores'
	fi
	sudo cp -Rvf /home/pi/.config/retroarch/cores/genesis_plus_gx_libretro.so /mnt/usb/blast16_backup/retroarch/cores

	if [ ! -d '/mnt/usb/blast16_backup/retroarch/shaders' ]; then
		sudo mkdir '/mnt/usb/blast16_backup/retroarch/shaders'
	fi
	sudo cp -vf /home/pi/.config/retroarch/shaders/retroarch.glslp /mnt/usb/blast16_backup/retroarch/shaders/
	sudo cp -Rvf /home/pi/.config/retroarch/shaders/presets /mnt/usb/blast16_backup/retroarch/shaders/
	
	if [ ! -d '/mnt/usb/blast16_backup/retroarch/shaders/shaders_glsl' ]; then
		sudo mkdir '/mnt/usb/blast16_backup/retroarch/shaders/shaders_glsl'
	fi
	sudo cp -Rvf /home/pi/.config/retroarch/shaders/shaders_glsl/crt /mnt/usb/blast16_backup/retroarch/shaders/shaders_glsl

	if [ -f '/etc/wpa_supplicant/wpa_supplicant.conf' ]; then
		sudo cp -vf /etc/wpa_supplicant/wpa_supplicant.conf /mnt/usb/blast16_backup/
	fi 
	
	sudo umount /mnt/usb

	echo "---------------------------------"
	echo "Finished backup. You can safely remove the USB drive. System will reboot in a few seconds."

	sleep 3

	sudo reboot
fi
