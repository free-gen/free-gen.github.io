# /bin/bash

/opt/vc/bin/vcgencmd measure_temp

