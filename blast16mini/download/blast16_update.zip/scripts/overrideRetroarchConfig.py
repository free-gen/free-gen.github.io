from os import listdir, stat, system 
from os.path import isfile, join, exists 
import time 
import commands 

rcfgoverride_file = "/tmp/retroarchOverride.txt"
retroarchcfg = "/home/pi/.config/retroarch/retroarch.cfg"

filter = ""
if ( exists( rcfgoverride_file )) :
	f = open (rcfgoverride_file, "r")
	rcfgorLines = f.readlines()
	f.close()

	variables = []
	values = []
	for l in rcfgorLines:
		var, val = l.split(' = ')
		variables.append(var)
		values.append(val)

	for i in range(0,len(variables)):
		var = variables[i]
		val = values[i]
		# print ("VAR2: " + var)
		# print ("VAL2: " + val)


	if ( exists( retroarchcfg ) ) :
		rcfg = open(retroarchcfg, "r")
		rcfglines = rcfg.readlines()
		rcfg.close()

		content = ""
		for rcfgline in rcfglines:
			nextLine = rcfgline
			for i in range(0, len(variables)):
				var = variables[i]
				val = values[i]

				if (rcfgline.find(var + " = ") <> -1):
					# nextLine = var + " = " + val + "\n"
					nextLine = var + " = " + val
					break

			content = content + nextLine

		rcfg = open (retroarchcfg, "w")
		rcfg.write(content)
		#print (content)
		rcfg.close()

	system('cp "/tmp/Genesis Plus GX.rmp" "/home/pi/.config/retroarch/config/remaps/Genesis Plus GX"');
	system('cp "/tmp/PicoDrive.rmp" "/home/pi/.config/retroarch/config/remaps/PicoDrive"');
