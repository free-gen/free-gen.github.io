from os import listdir, stat, system
from os.path import isfile, join, exists
import time
import commands

mainPath = "/home/pi/blast16/"
statespath = mainPath + "saves/states/"
datapath = mainPath + "data/blast16/"

rtfilename = "lastResizeStateThumbnailsTime.txt"
if ( exists( join( datapath, rtfilename ) ) ):
	rtfile = open ( join( datapath, rtfilename ), "r" )
	lastresizetime = rtfile.read()
	lastresizetime = float(lastresizetime)
	rtfile.close()
else:
	#print "No last resize time file found"
	lastresizetime = time.time()
	rtfile = open ( join( datapath, rtfilename ), "w+" )
	rtfile.write( str(lastresizetime ) )
	rtfile.close()

systems = [ "32x", "cd", "gg", "md", "ms" ]
for sys in systems:
	sysStatesPath = join( statespath, sys )

	statefiles = [f for f in listdir(sysStatesPath) if isfile( join( sysStatesPath, f ) )]

	for f in statefiles:
		if ( f.find( ".png" ) != -1 ):
			if ( f.find( ".auto" ) != -1 ):
				system('rm "' + join( sysStatesPath, f ) + '"' )
			else:
				statepath = join( sysStatesPath, f )
				status = stat( statepath )

				# print ("-----------------------------------------")
				# print ("LAST RESIZE TIME: " + str(lastresizetime))
				# print (statepath + " RESIZE TIME: " + str(status.st_mtime))
				
				if ( status.st_mtime > lastresizetime ):
					width = commands.getoutput('identify -ping -format %w "' +  statepath + '"')
					# if ( float( width ) > 210):
						# print "Resize state thumbnail: " + f
						# system('convert "' + statepath + '" -resize "210x160!" "' +  statepath + '"' )
						
					# print "Resize state thumbnail: " + f
					system('convert "' + statepath + '" -resize "210x160!" "' +  statepath + '"' )
					
					rtfile = open( join( datapath, rtfilename ), "w+" )
					rtfile.write( str( time.time( ) ) )
					rtfile.close()

