from os import listdir, stat, system 
from os.path import isfile, join, exists 
import time 
import commands 

bffile = "/tmp/bilinearFilter"
ssfile = "/tmp/stateSlot"
olfile = "/tmp/overlay"
configfile = "/home/pi/.config/retroarch/retroarch.cfg"

filter = ""
if ( exists( bffile )) :
	if ( exists( bffile ) ) :
		bff = open (bffile, "r")
		lines = bff.readlines()
		bff.close()
		filter = lines[0]
	
	if ( exists( ssfile ) ) :
		ssf = open (ssfile, "r")
		lines = ssf.readlines()
		ssf.close()
		stateSlot = lines[0]
	
	if ( exists( olfile ) ) :
		olf = open (olfile, "r")
		lines = olf.readlines()
		olf.close()
		overlay = lines[0]
	
	if ( exists( configfile ) ) :
		spf = open(configfile, "r")
		splines = spf.readlines()
		spf.close()

		content = ""
		for line in splines:
			if (line.find("video_smooth =") <> -1):
				content = content  + "video_smooth = \"" + filter + "\"\n"
			elif (line.find("state_slot =") <> -1):
				content = content  + "state_slot = \"" + stateSlot + "\"\n"
			elif (line.find("input_overlay =") <> -1):
				content = content  + "input_overlay = \"" + overlay + "\"\n"
			else:
				content = content + line

		spf = open (configfile, "w")
		spf.write(content)
		spf.close()
