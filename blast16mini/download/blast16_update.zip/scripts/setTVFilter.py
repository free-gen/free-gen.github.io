from os import listdir, stat, system 
from os.path import isfile, join, exists 
import time 
import commands 

valuefile = "/tmp/tvfilter"
configfile = "/home/pi/.config/retroarch/retroarch-core-options.cfg"

filter = ""
if ( exists( valuefile )) :
	f = open (valuefile, "r")
	lines = f.readlines()
	f.close()
	filter = lines[0]

	if ( exists( configfile ) ) :
		spf = open(configfile, "r")
		splines = spf.readlines()
		spf.close()

		content = ""
		for line in splines:
			if (line.find("genesis_plus_gx_blargg_ntsc_filter =") <> -1):
				content = content  + "genesis_plus_gx_blargg_ntsc_filter = \"" + filter + "\"\n"
			else:
				content = content + line

		spf = open (configfile, "w")
		spf.write(content)
		spf.close()
