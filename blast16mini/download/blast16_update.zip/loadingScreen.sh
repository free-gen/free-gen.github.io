#bin/bash

#FILE=/home/pi/blast16/data/blast16/img/bg/loadingScreen.jpg

# ( sleep 6 ; sudo kill $(pgrep fbi)  ) &
# ( sleep 8 ; sudo pkill fbi  > /dev/null 2>&1; clear) &

#sudo fbi -noverbose -a -T 2 $FILE > /dev/null 2>&1
# sudo fbi -noverbose -a -d /dev/fb0 -T 1 $FILE >& /dev/null 2>&1
#sudo fbi -noverbose -a -d /dev/fb0 -T 1 $FILE >/dev/null 2>&1

#clear

