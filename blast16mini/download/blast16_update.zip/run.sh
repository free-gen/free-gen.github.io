#!/bin/bash

setterm -cursor off

./preload.sh

file="/home/pi/blast16/data/blast16/launchgame.sh"
while true
do
        if [ -f '/tmp/stop' ]; then
                rm '/tmp/stop'
                break
        fi
		
		# Get IP
		python /home/pi/blast16/scripts/getIP.py

		# Resize scripts
        python /home/pi/blast16/scripts/resizeThumbnails.py

        if [ -f $file ]; then
                rm $file
        fi

		( sleep 3 ; sudo pkill fbi  >/dev/null 2>&1; clear) &
        XDG_DATA_HOME=/home/pi/blast16/data ./blast16
		setterm -cursor off

        clear

        if [ -f $file ]; then
                /home/pi/blast16/data/blast16/launchgame.sh
                clear
        else
                break
        fi
done

setterm -cursor on

exit 0
