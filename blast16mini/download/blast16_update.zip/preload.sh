#!/bin/bash

# Permissions restore, just in case

sudo chown -R pi:pi /home/pi/
# if [ ! -f '/home/pi/blast16/data/blast16/firstBoot' ]; then
	# sudo chown -R pi:pi /home/pi/
# fi


# Delete games and boxarts from previous versions; currently games are classified in different directories
sudo rm -v /home/pi/blast16/games/* 2>&1 | grep -v 'cannot remove .*: Is a directory'
if [ -d '/home/pi/blast16/games/boxarts' ]; then
	sudo rm -Rv /home/pi/blast16/games/boxarts
fi


# clean possible MacOS and Windows system files that might crash the app
find /home/pi/blast16/games/ -name Thumbs.db -type f -delete 
find /home/pi/blast16/games/ -name ._* -type f -delete 
find /home/pi/blast16/saves/states/ -name ._* -type f -delete 

# existMacFiles=`find /home/pi/blast16/games/ -name ._*`
# if [ -n "${existMacFiles}" ]; then
	# find /home/pi/blast16/games/ -name ._* -type f -delete 
	# find /home/pi/blast16/saves/states/ -name ._* -type f -delete 

	# sudo rm -v /home/pi/blast16/games/md/._* 2>&1 | grep -v 'cannot remove .*: No such file or directory'
	# sudo rm -v /home/pi/blast16/games/md/boxarts/._* 2>&1 | grep -v 'cannot remove .*: No such file or directory'

	# sudo rm -v /home/pi/blast16/games/ms/._* 2>&1 | grep -v 'cannot remove .*: No such file or directory'
	# sudo rm -v /home/pi/blast16/games/ms/boxarts/._* 2>&1 | grep -v 'cannot remove .*: No such file or directory'

	# sudo rm -v /home/pi/blast16/games/cd/._* 2>&1 | grep -v 'cannot remove .*: No such file or directory'
	# sudo rm -v /home/pi/blast16/games/cd/boxarts/._* 2>&1 | grep -v 'cannot remove .*: No such file or directory'

	# sudo rm -v /home/pi/blast16/games/gg/._* 2>&1 | grep -v 'cannot remove .*: No such file or directory'
	# sudo rm -v /home/pi/blast16/games/gg/boxarts/._* 2>&1 | grep -v 'cannot remove .*: No such file or directory'

	# sudo rm -v /home/pi/blast16/games/32x/._* 2>&1 | grep -v 'cannot remove .*: No such file or directory'
	# sudo rm -v /home/pi/blast16/games/32x/boxarts/._* 2>&1 | grep -v 'cannot remove .*: No such file or directory'

	# sudo rm -v /home/pi/blast16/saves/states/._* 2>&1 | grep -v 'cannot remove .*: No such file or directory'
# fi

# Rename files which have different names now than in previous versions
if [ -f '/home/pi/blast16/data/blast16/lastresizeboxarttime.txt' ]; then
	mv '/home/pi/blast16/data/blast16/lastresizeboxarttime.txt' '/home/pi/blast16/data/blast16/lastResizeBoxartTime.txt'
fi
if [ -f '/home/pi/blast16/data/blast16/lastresizetime.txt' ]; then
	mv '/home/pi/blast16/data/blast16/lastresizetime.txt' '/home/pi/blast16/data/blast16/lastResizeStateThumbnailsTime.txt'
fi


# Start bluetooth service
BTSTATUS=`systemctl is-active bluetooth`
if [ $BTSTATUS != 'active' ]; then
	sudo systemctl start bluetooth 2>&1
fi


# Fixing extensions in capitals for all games
cd /home/pi/blast16/games
find . -name "*.BIN" -exec rename 's/\.BIN$/.bin/' '{}' \;
find . -name "*.SMD" -exec rename 's/\.SMD$/.smd/' '{}' \;
find . -name "*.MD" -exec rename 's/\.MD$/.md/' '{}' \;
find . -name "*.GEN" -exec rename 's/\.GEN$/.gen/' '{}' \;
find . -name "*.GG" -exec rename 's/\.GG$/.gg/' '{}' \;
find . -name "*.SMS" -exec rename 's/\.SMS$/.sms/' '{}' \;
find . -name "*.32X" -exec rename 's/\.32X$/.32x/' '{}' \;
find . -name "*.CHD" -exec rename 's/\.CHD$/.chd/' '{}' \;
find . -name "*.CUE" -exec rename 's/\.CUE$/.cue/' '{}' \;
find . -name "*.ISO" -exec rename 's/\.ISO$/.iso/' '{}' \;
find . -name "*.IMG" -exec rename 's/\.IMG$/.img/' '{}' \;
find . -name "*.ZIP" -exec rename 's/\.ZIP$/.zip/' '{}' \;
find . -name "*.7Z" -exec rename 's/\.7Z$/.7z/' '{}' \;


# Copy the alsamixer settings backup
sudo cp /home/pi/blast16/data/blast16/asound.state /var/lib/alsa/
amixer sset PCM,0 97% >/dev/null &


# If any save state is found in srm or states, copy them to all systems directories
srmFiles=`find "/home/pi/blast16/saves/srm/" -mindepth 1 -maxdepth 1 -type f | wc -l`
if [ $srmFiles -gt 0 ]; then 
	sudo cp /home/pi/blast16/saves/srm/* /home/pi/blast16/saves/srm/32x/  2>&1 | grep -v 'not specified; omitting directory .*'
	sudo cp /home/pi/blast16/saves/srm/* /home/pi/blast16/saves/srm/cd/  2>&1 | grep -v 'not specified; omitting directory .*'
	sudo cp /home/pi/blast16/saves/srm/* /home/pi/blast16/saves/srm/gg/  2>&1 | grep -v 'not specified; omitting directory .*'
	sudo cp /home/pi/blast16/saves/srm/* /home/pi/blast16/saves/srm/md/  2>&1 | grep -v 'not specified; omitting directory .*'
	sudo cp /home/pi/blast16/saves/srm/* /home/pi/blast16/saves/srm/ms/  2>&1 | grep -v 'not specified; omitting directory .*'

	sudo rm /home/pi/blast16/saves/srm/* 2>&1 | grep -v 'cannot remove .*: Is a directory'
fi

statesFiles=`find "/home/pi/blast16/saves/states/" -mindepth 1 -maxdepth 1 -type f | wc -l`
if [ $statesFiles -gt 0 ]; then 
	sudo cp /home/pi/blast16/saves/states/* /home/pi/blast16/saves/states/32x/  2>&1 | grep -v 'not specified; omitting directory .*'
	sudo cp /home/pi/blast16/saves/states/* /home/pi/blast16/saves/states/cd/  2>&1 | grep -v 'not specified; omitting directory .*'
	sudo cp /home/pi/blast16/saves/states/* /home/pi/blast16/saves/states/gg/  2>&1 | grep -v 'not specified; omitting directory .*'
	sudo cp /home/pi/blast16/saves/states/* /home/pi/blast16/saves/states/md/  2>&1 | grep -v 'not specified; omitting directory .*'
	sudo cp /home/pi/blast16/saves/states/* /home/pi/blast16/saves/states/ms/  2>&1 | grep -v 'not specified; omitting directory .*'

	sudo rm /home/pi/blast16/saves/states/* 2>&1 | grep -v 'cannot remove .*: Is a directory'
fi

# if there are pngs, run resizeBoxarts
pngs=`find "/home/pi/blast16/games/" -name "*.png" -type f | wc -l`
if [ $pngs -gt 0 ]; then 
	python /home/pi/blast16/scripts/resizeBoxarts.py
fi


# make sure Genesis Plus GX and PicoDrive cores are in place
# cp /home/pi/blast16/cores/genesis_plus_gx_libretro.so /home/pi/.config/retroarch/cores
# cp /home/pi/blast16/cores/picodrive_libretro.so /home/pi/.config/retroarch/cores

# # Copy new overlays
# if [ -d '/home/pi/blast16/img/overlay' ]; then
	# cp -v /home/pi/blast16/img/overlay/* '/home/pi/blast16/data/blast16/img/overlay/'
	# sudo rm -r '/home/pi/blast16/img'
# fi

# # Remove old overlays
# if [ -f '/home/pi/blast16/data/blast16/img/overlay/blast16blue.cfg' ]; then
	# sudo rm '/home/pi/blast16/data/blast16/img/overlay/blast16blue.cfg'
	# sudo rm '/home/pi/blast16/data/blast16/img/overlay/blast16blue.png'
# fi
# if [ -f '/home/pi/blast16/data/blast16/img/overlay/blast16purple.cfg' ]; then
	# sudo rm '/home/pi/blast16/data/blast16/img/overlay/blast16purple.cfg'
	# sudo rm '/home/pi/blast16/data/blast16/img/overlay/blast16purple.png'
# fi
# if [ -f '/home/pi/blast16/data/blast16/img/overlay/grid.cfg' ]; then
	# sudo rm '/home/pi/blast16/data/blast16/img/overlay/grid.cfg'
	# sudo rm '/home/pi/blast16/data/blast16/img/overlay/grid.png'
# fi


# # Copy new input mapping presets
# if [ -d '/home/pi/blast16/input/presets' ]; then
	# cp -v /home/pi/blast16/input/presets/* '/home/pi/blast16/data/blast16/input/presets/'
	# sudo rm -r '/home/pi/blast16/input'
# fi

# Getting back to start directory
cd /home/pi/blast16

# Permissions restore again, if first boot
sudo chown -R pi:pi /home/pi/
# if [ ! -f '/home/pi/blast16/data/blast16/firstBoot' ]; then
	# sudo chown -R pi:pi /home/pi/
	# touch '/home/pi/blast16/data/blast16/firstBoot'
# fi

exit 0
