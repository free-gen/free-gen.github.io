#!/bin/bash

# USB OPERATIONS BEFORE LAUNCH

# Permissions restore, just in case
sudo chown -R pi:pi /home/pi/

# create all games directories if they don't exist already
if [ -d '/mnt/usb/games/md' ]; then
	mkdir '/mnt/usb/games/md'
fi
if [ -d '/mnt/usb/games/md/boxarts' ]; then
	mkdir '/mnt/usb/games/md/boxarts'
fi

if [ -d '/mnt/usb/games/ms' ]; then
	mkdir '/mnt/usb/games/ms'
fi
if [ -d '/mnt/usb/games/ms/boxarts' ]; then
	mkdir '/mnt/usb/games/ms/boxarts'
fi

if [ -d '/mnt/usb/games/gg' ]; then
	mkdir '/mnt/usb/games/gg'
fi
if [ -d '/mnt/usb/games/gg/boxarts' ]; then
	mkdir '/mnt/usb/games/gg/boxarts'
fi

if [ -d '/mnt/usb/games/cd' ]; then
	mkdir '/mnt/usb/games/cd'
fi
if [ -d '/mnt/usb/games/cd/boxarts' ]; then
	mkdir '/mnt/usb/games/cd/boxarts'
fi

if [ -d '/mnt/usb/games/32x' ]; then
	mkdir '/mnt/usb/games/32x'
fi
if [ -d '/mnt/usb/games/32x/boxarts' ]; then
	mkdir '/mnt/usb/games/32x/boxarts'
fi

# Detect usb device
if [ -e '/dev/sda1' ]; then
	USBDEV='/dev/sda1'
elif [ -e '/dev/sdb1' ]; then
	USBDEV='/dev/sdb1'
fi

# If USB was detected, start doing stuff
if [ -n "$USBDEV" ]; then
	if [ ! -d '/mnt/usb' ]; then
		sudo mkdir '/mnt/usb'
	fi
	
	# Detect USB format and mount accordingly
	USBFORMAT=`sudo blkid | grep $USBDEV | tr -s ' ' | cut -d ' ' -f 4 | cut -d '=' -f 2 | sed 's/"//g'`
	if [ "$USBFORMAT" == "exfat" ]; then
		sudo mount -t exfat "$USBDEV" /mnt/usb
		echo "exfat USB Mounted"
	else 
		sudo mount "$USBDEV" /mnt/usb
		echo "USB Mounted"
	fi
	

	# copy bios
	if [ -d '/mnt/usb/bios' ]; then
		if [ ! -d '/home/pi/blast16/bios' ]; then
			sudo mkdir '/home/pi/blast16/bios'
		fi
	
		echo "Copying bios from USB drive. Please wait."
		sudo cp -vnf /mnt/usb/bios/* /home/pi/blast16/bios/ 
		echo "Finished copying bios"
		echo "---------------------------------"
	else
		echo "No bios found"
	fi
	
	# copy roms
	if [ -d '/mnt/usb/games' ]; then
		echo "Copying games from USB drive. Please wait."
		
		sudo chown -R pi:pi /home/pi/
		
		sudo cp -vrnf /mnt/usb/games/* /home/pi/blast16/games/ 
		echo "Finished copying games"
		echo "---------------------------------"
		
		sudo chown -R pi:pi /home/pi/
        python /home/pi/blast16/scripts/resizeBoxarts.py
	else
		echo "No games found"
	fi
	
	# copy custom  splash
	if [ -f '/mnt/usb/splash.png' ]; then
		echo "Copying custom splash from USB drive."
		sudo cp /mnt/usb/splash.png /home/pi/blast16/data/blast16/ >/dev/null 2>&1
		echo "Finished copying custom splash"
		echo "---------------------------------"
	else
		echo "No custom splash found"
	fi
	
	# copy blast16 update and perform update
	if [ -f '/mnt/usb/blast16_update.zip' ]; then
		echo "Updating Blast16"

		# Delete looped retroarch directories created by mistake by the backup script.
		if [ -d "/home/pi/.config/retroarch/retroarch" ]; then
			sudo rm -r "/home/pi/.config/retroarch/retroarch"
		fi

		sudo cp /mnt/usb/blast16_update.zip /home/pi/blast16/ >/dev/null 2>&1
		
		sudo unzip -o /home/pi/blast16/blast16_update.zip
		
		sudo chmod +x /home/pi/blast16/blast16
		sudo chmod +x /home/pi/blast16/*.sh
		sudo chmod +x /home/pi/blast16/scripts/*.sh
		
		sudo rm /home/pi/blast16/blast16_update.zip
		echo "Finished updating Blast16"
		echo "---------------------------------"
	else
		echo "No blast16 update file found"
	fi

	# Permissions restore, just in case
	
	sudo umount /mnt/usb
	echo "USB unmounted. You can safely remove it. If you copied a lot of games with boxarts, Blast16 might take some time to start."

fi

sudo chown -R pi:pi /home/pi/
